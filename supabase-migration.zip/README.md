# SQLite to Supabase Migration

This directory contains files and scripts for migrating data from SQLite to Supabase.

## Files

- `schema.sql`: The original SQLite schema
- `postgres-schema.sql`: The converted PostgreSQL schema for Supabase
- `export-data.js`: A script to export data from SQLite tables to CSV files
- `tables/`: Directory containing CSV files with exported table data

## Migration Steps

1. **Backup the SQLite Database**
   - The original SQLite database has been backed up to `src/db/` directory

2. **Export Schema and Data**
   - SQLite schema exported to `schema.sql`
   - Table data exported to CSV files in `tables/` directory using `export-data.js`

3. **Convert Schema to PostgreSQL**
   - Schema converted to PostgreSQL format in `postgres-schema.sql`
   - Added Supabase-specific elements like RLS policies and triggers

4. **Create Supabase Project**
   - Create a new Supabase project named "yayasan partisipasi muda"
   - Run the PostgreSQL schema script in the SQL editor

5. **Import Data**
   - Import the CSV files into the corresponding tables
   - Resolve any data type or constraint issues during import

## Data Mapping Considerations

- SQLite INTEGER PRIMARY KEY AUTOINCREMENT → PostgreSQL UUID PRIMARY KEY DEFAULT uuid_generate_v4()
- SQLite TEXT → PostgreSQL TEXT
- SQLite DATETIME → PostgreSQL TIMESTAMPTZ
- SQLite INTEGER for booleans → PostgreSQL BOOLEAN
- Auto-updating timestamps are handled with triggers in PostgreSQL

## Row Level Security (RLS)

The PostgreSQL schema includes basic Row Level Security (RLS) policies:

- All tables have RLS enabled
- Users can only see their own data, or all data if they are an admin
- Only admins can create new users
- Users can only update their own data, or all data if they are an admin

## Environment Updates

After migration, update your application to use Supabase instead of SQLite:

1. Install the Supabase client:
   ```
   npm install @supabase/supabase-js
   ```

2. Create a Supabase client in your application:
   ```typescript
   import { createClient } from '@supabase/supabase-js'

   const supabaseUrl = 'YOUR_SUPABASE_URL'
   const supabaseKey = 'YOUR_SUPABASE_KEY'
   const supabase = createClient(supabaseUrl, supabaseKey)
   ```

3. Replace SQLite queries with Supabase queries in your application code. 