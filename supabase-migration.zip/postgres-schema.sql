-- PostgreSQL schema for Supabase migration from SQLite
-- Main tables

-- Enable UUID extension for generating IDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE IF NOT EXISTS "users" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "email" TEXT UNIQUE NOT NULL,
  "name" TEXT,
  "password" TEXT,
  "role" TEXT DEFAULT 'USER',
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Profiles table
CREATE TABLE IF NOT EXISTS "profiles" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "user_id" UUID REFERENCES users(id),
  "email" TEXT,
  "name" TEXT,
  "bio" TEXT,
  "image" TEXT,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Categories table
CREATE TABLE IF NOT EXISTS "categories" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "name" TEXT NOT NULL,
  "slug" TEXT UNIQUE NOT NULL,
  "description" TEXT,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tags table
CREATE TABLE IF NOT EXISTS "tags" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "name" TEXT NOT NULL,
  "slug" TEXT UNIQUE NOT NULL,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Event categories table
CREATE TABLE IF NOT EXISTS "event_categories" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "name" TEXT NOT NULL,
  "slug" TEXT UNIQUE NOT NULL,
  "description" TEXT,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Events table
CREATE TABLE IF NOT EXISTS "events" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "title" TEXT NOT NULL,
  "slug" TEXT UNIQUE NOT NULL,
  "description" TEXT NOT NULL,
  "content" TEXT,
  "location" TEXT NOT NULL,
  "venue" TEXT,
  "start_date" TIMESTAMPTZ NOT NULL,
  "end_date" TIMESTAMPTZ NOT NULL,
  "poster_image" TEXT,
  "poster_credit" TEXT,
  "status" TEXT NOT NULL,
  "published" BOOLEAN NOT NULL DEFAULT FALSE,
  "category_id" UUID REFERENCES event_categories(id),
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Speakers table
CREATE TABLE IF NOT EXISTS "speakers" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "first_name" TEXT NOT NULL,
  "last_name" TEXT NOT NULL,
  "title" TEXT,
  "bio" TEXT,
  "organization" TEXT,
  "photo_url" TEXT,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Event speakers junction table
CREATE TABLE IF NOT EXISTS "event_speakers" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "event_id" UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  "speaker_id" UUID NOT NULL REFERENCES speakers(id) ON DELETE CASCADE,
  "display_order" INTEGER NOT NULL,
  "role" TEXT,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE("event_id", "speaker_id")
);

-- Publications table
CREATE TABLE IF NOT EXISTS "publications" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "title" TEXT NOT NULL,
  "slug" TEXT UNIQUE NOT NULL,
  "abstract" TEXT NOT NULL,
  "content" TEXT,
  "publication_date" TIMESTAMPTZ,
  "cover_image" TEXT,
  "image_credit" TEXT,
  "published" BOOLEAN NOT NULL DEFAULT FALSE,
  "category_id" UUID REFERENCES event_categories(id),
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Categories on publications junction table
CREATE TABLE IF NOT EXISTS "categories_on_publications" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "publication_id" UUID NOT NULL REFERENCES publications(id) ON DELETE CASCADE,
  "category_id" UUID NOT NULL REFERENCES event_categories(id) ON DELETE CASCADE,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE("publication_id", "category_id")
);

-- Tags on publications junction table
CREATE TABLE IF NOT EXISTS "tags_on_publications" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "publication_id" UUID NOT NULL REFERENCES publications(id) ON DELETE CASCADE,
  "tag_id" UUID NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE("publication_id", "tag_id")
);

-- Tags on events junction table
CREATE TABLE IF NOT EXISTS "tags_on_events" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "event_id" UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  "tag_id" UUID NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE("event_id", "tag_id")
);

-- Publication files table
CREATE TABLE IF NOT EXISTS "publication_files" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "name" TEXT NOT NULL,
  "url" TEXT NOT NULL,
  "size" INTEGER NOT NULL,
  "type" TEXT NOT NULL,
  "publication_id" UUID NOT NULL REFERENCES publications(id) ON DELETE CASCADE,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Presentations table
CREATE TABLE IF NOT EXISTS "presentations" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "title" TEXT NOT NULL,
  "abstract" TEXT,
  "speaker_id" UUID NOT NULL REFERENCES speakers(id) ON DELETE CASCADE,
  "event_id" UUID REFERENCES events(id) ON DELETE SET NULL,
  "slides" TEXT,
  "video_url" TEXT,
  "duration" INTEGER,
  "start_time" TIMESTAMPTZ,
  "end_time" TIMESTAMPTZ,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Authors table
CREATE TABLE IF NOT EXISTS "authors" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "first_name" TEXT NOT NULL,
  "last_name" TEXT NOT NULL,
  "email" TEXT UNIQUE NOT NULL,
  "phone_number" TEXT,
  "organization" TEXT,
  "bio" TEXT,
  "category" TEXT NOT NULL,
  "photo_url" TEXT,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Authors on publications junction table
CREATE TABLE IF NOT EXISTS "authors_on_publications" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "publication_id" UUID NOT NULL REFERENCES publications(id) ON DELETE CASCADE,
  "author_id" UUID NOT NULL REFERENCES authors(id) ON DELETE CASCADE,
  "display_order" INTEGER NOT NULL,
  "role" TEXT,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE("publication_id", "author_id")
);

-- Projects table
CREATE TABLE IF NOT EXISTS "projects" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "title" TEXT NOT NULL,
  "description" TEXT,
  "start_date" TIMESTAMPTZ,
  "due_date" TIMESTAMPTZ,
  "status" TEXT NOT NULL DEFAULT 'ACTIVE',
  "owner_id" UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  "deleted" BOOLEAN DEFAULT FALSE,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Project members junction table
CREATE TABLE IF NOT EXISTS "project_members" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "project_id" UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  "user_id" UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  "role" TEXT NOT NULL,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE("project_id", "user_id")
);

-- Milestones table
CREATE TABLE IF NOT EXISTS "milestones" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "project_id" UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  "title" TEXT NOT NULL,
  "description" TEXT,
  "due_date" TIMESTAMPTZ,
  "status" TEXT NOT NULL DEFAULT 'PENDING',
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tasks table
CREATE TABLE IF NOT EXISTS "tasks" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "title" TEXT NOT NULL,
  "description" TEXT,
  "status" TEXT NOT NULL,
  "priority" TEXT NOT NULL,
  "due_date" TIMESTAMPTZ,
  "completed_date" TIMESTAMPTZ,
  "delegated_by" UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  "assigned_to" UUID REFERENCES users(id) ON DELETE SET NULL,
  "review_status" TEXT DEFAULT 'PENDING',
  "review_comment" TEXT,
  "review_date" TIMESTAMPTZ,
  "created_by" UUID REFERENCES users(id) ON DELETE SET NULL,
  "agent_id" TEXT,
  "tags" TEXT,
  "shared_files" TEXT,
  "deleted" BOOLEAN DEFAULT FALSE,
  "project_id" UUID REFERENCES projects(id) ON DELETE SET NULL,
  "parent_task_id" UUID REFERENCES tasks(id) ON DELETE SET NULL,
  "estimated_hours" REAL,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Time logs table
CREATE TABLE IF NOT EXISTS "time_logs" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "task_id" UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  "user_id" UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  "start_time" TIMESTAMPTZ NOT NULL,
  "end_time" TIMESTAMPTZ,
  "duration" INTEGER,
  "notes" TEXT,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Comments table
CREATE TABLE IF NOT EXISTS "comments" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "content" TEXT NOT NULL,
  "entity_type" TEXT NOT NULL,
  "entity_id" UUID NOT NULL,
  "user_id" UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  "parent_comment_id" UUID REFERENCES comments(id) ON DELETE SET NULL,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Attachments table
CREATE TABLE IF NOT EXISTS "attachments" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "file_name" TEXT NOT NULL,
  "file_size" INTEGER NOT NULL,
  "file_type" TEXT NOT NULL,
  "file_path" TEXT NOT NULL,
  "entity_type" TEXT NOT NULL,
  "entity_id" UUID NOT NULL,
  "user_id" UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  "version" INTEGER DEFAULT 1,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Notifications table
CREATE TABLE IF NOT EXISTS "notifications" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "user_id" UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  "title" TEXT NOT NULL,
  "message" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "entity_type" TEXT NOT NULL,
  "entity_id" UUID NOT NULL,
  "is_read" BOOLEAN DEFAULT FALSE,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Error logs table
CREATE TABLE IF NOT EXISTS "error_logs" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "message" TEXT NOT NULL,
  "stack" TEXT,
  "path" TEXT,
  "method" TEXT,
  "user_id" UUID REFERENCES users(id) ON DELETE SET NULL,
  "severity" TEXT DEFAULT 'ERROR',
  "metadata" JSONB,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS "idx_events_status" ON events(status);
CREATE INDEX IF NOT EXISTS "idx_events_published" ON events(published);
CREATE INDEX IF NOT EXISTS "idx_events_category_id" ON events(category_id);
CREATE INDEX IF NOT EXISTS "idx_events_start_date" ON events(start_date);
CREATE INDEX IF NOT EXISTS "idx_events_title" ON events(title);
CREATE INDEX IF NOT EXISTS "idx_events_created_at" ON events(created_at);
CREATE INDEX IF NOT EXISTS "idx_event_categories_slug" ON event_categories(slug);
CREATE INDEX IF NOT EXISTS "idx_event_categories_name" ON event_categories(name);
CREATE INDEX IF NOT EXISTS "idx_publications_published" ON publications(published);
CREATE INDEX IF NOT EXISTS "idx_publications_category_id" ON publications(category_id);
CREATE INDEX IF NOT EXISTS "idx_publications_title" ON publications(title);
CREATE INDEX IF NOT EXISTS "idx_publications_created_at" ON publications(created_at);
CREATE INDEX IF NOT EXISTS "idx_tags_name" ON tags(name);
CREATE INDEX IF NOT EXISTS "idx_tags_slug" ON tags(slug);
CREATE INDEX IF NOT EXISTS "idx_categories_slug" ON categories(slug);
CREATE INDEX IF NOT EXISTS "idx_users_email" ON users(email);
CREATE INDEX IF NOT EXISTS "idx_users_role" ON users(role);
CREATE INDEX IF NOT EXISTS "idx_profiles_user_id" ON profiles(user_id);
CREATE INDEX IF NOT EXISTS "idx_profiles_email" ON profiles(email);
CREATE INDEX IF NOT EXISTS "idx_event_speakers_event_id" ON event_speakers(event_id);
CREATE INDEX IF NOT EXISTS "idx_event_speakers_speaker_id" ON event_speakers(speaker_id);
CREATE INDEX IF NOT EXISTS "idx_categories_publications_publication_id" ON categories_on_publications(publication_id);
CREATE INDEX IF NOT EXISTS "idx_tags_events_event_id" ON tags_on_events(event_id);
CREATE INDEX IF NOT EXISTS "idx_tags_publications_publication_id" ON tags_on_publications(publication_id);
CREATE INDEX IF NOT EXISTS "idx_publication_files_publication_id" ON publication_files(publication_id);
CREATE INDEX IF NOT EXISTS "idx_presentations_speaker_id" ON presentations(speaker_id);
CREATE INDEX IF NOT EXISTS "idx_presentations_event_id" ON presentations(event_id);
CREATE INDEX IF NOT EXISTS "idx_presentations_title" ON presentations(title);
CREATE INDEX IF NOT EXISTS "idx_presentations_start_time" ON presentations(start_time);
CREATE INDEX IF NOT EXISTS "idx_authors_email" ON authors(email);
CREATE INDEX IF NOT EXISTS "idx_authors_category" ON authors(category);
CREATE INDEX IF NOT EXISTS "idx_authors_publications_pub" ON authors_on_publications(publication_id);
CREATE INDEX IF NOT EXISTS "idx_authors_publications_author" ON authors_on_publications(author_id);
CREATE INDEX IF NOT EXISTS "idx_projects_owner" ON projects(owner_id);
CREATE INDEX IF NOT EXISTS "idx_projects_deleted" ON projects(deleted);
CREATE INDEX IF NOT EXISTS "idx_project_members_project" ON project_members(project_id);
CREATE INDEX IF NOT EXISTS "idx_project_members_user" ON project_members(user_id);
CREATE INDEX IF NOT EXISTS "idx_milestones_project" ON milestones(project_id);
CREATE INDEX IF NOT EXISTS "idx_tasks_project" ON tasks(project_id);
CREATE INDEX IF NOT EXISTS "idx_tasks_parent" ON tasks(parent_task_id);
CREATE INDEX IF NOT EXISTS "idx_tasks_delegated_by" ON tasks(delegated_by);
CREATE INDEX IF NOT EXISTS "idx_tasks_assigned_to" ON tasks(assigned_to);
CREATE INDEX IF NOT EXISTS "idx_tasks_status" ON tasks(status);
CREATE INDEX IF NOT EXISTS "idx_tasks_review_status" ON tasks(review_status);
CREATE INDEX IF NOT EXISTS "idx_tasks_deleted" ON tasks(deleted);
CREATE INDEX IF NOT EXISTS "idx_time_logs_task" ON time_logs(task_id);
CREATE INDEX IF NOT EXISTS "idx_time_logs_user" ON time_logs(user_id);
CREATE INDEX IF NOT EXISTS "idx_comments_entity" ON comments(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS "idx_attachments_entity" ON attachments(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS "idx_notifications_user" ON notifications(user_id);
CREATE INDEX IF NOT EXISTS "idx_error_logs_created_at" ON error_logs(created_at);
CREATE INDEX IF NOT EXISTS "idx_error_logs_severity" ON error_logs(severity);

-- RLS Policies
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE speakers ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_speakers ENABLE ROW LEVEL SECURITY;
ALTER TABLE publications ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories_on_publications ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags_on_publications ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags_on_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE publication_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE presentations ENABLE ROW LEVEL SECURITY;
ALTER TABLE authors ENABLE ROW LEVEL SECURITY;
ALTER TABLE authors_on_publications ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE time_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE error_logs ENABLE ROW LEVEL SECURITY;

-- Example RLS policy for users (You might want to customize these)
CREATE POLICY "Users can view their own data" ON users
  FOR SELECT USING (auth.uid() = id OR auth.uid() IN (SELECT id FROM users WHERE role = 'ADMIN'));

CREATE POLICY "Only admins can insert users" ON users
  FOR INSERT WITH CHECK (auth.uid() IN (SELECT id FROM users WHERE role = 'ADMIN'));

CREATE POLICY "Only self or admins can update users" ON users
  FOR UPDATE USING (auth.uid() = id OR auth.uid() IN (SELECT id FROM users WHERE role = 'ADMIN'));

-- Trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply the trigger to all tables with updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_categories_updated_at BEFORE UPDATE ON categories FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_tags_updated_at BEFORE UPDATE ON tags FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_event_categories_updated_at BEFORE UPDATE ON event_categories FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_events_updated_at BEFORE UPDATE ON events FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_speakers_updated_at BEFORE UPDATE ON speakers FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_event_speakers_updated_at BEFORE UPDATE ON event_speakers FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_publications_updated_at BEFORE UPDATE ON publications FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_publication_files_updated_at BEFORE UPDATE ON publication_files FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_presentations_updated_at BEFORE UPDATE ON presentations FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_authors_updated_at BEFORE UPDATE ON authors FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_authors_on_publications_updated_at BEFORE UPDATE ON authors_on_publications FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON projects FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_project_members_updated_at BEFORE UPDATE ON project_members FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_milestones_updated_at BEFORE UPDATE ON milestones FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON tasks FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_time_logs_updated_at BEFORE UPDATE ON time_logs FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_comments_updated_at BEFORE UPDATE ON comments FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_attachments_updated_at BEFORE UPDATE ON attachments FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column(); 