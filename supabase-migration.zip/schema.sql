CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      name TEXT,
      password TEXT,
      role TEXT DEFAULT 'USER',
      createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
CREATE TABLE sqlite_sequence(name,seq);
CREATE TABLE profiles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER,
      email TEXT,
      name TEXT,
      bio TEXT,
      image TEXT,
      createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (userId) REFERENCES users(id)
    );
CREATE TABLE categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT,
      createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
CREATE TABLE tags (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
CREATE TABLE EventCategory (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT,
      createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
CREATE TABLE Event (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT,
      content TEXT,
      location TEXT,
      venue TEXT,
      startDate DATETIME,
      endDate DATETIME,
      posterImage TEXT,
      posterCredit TEXT,
      status TEXT DEFAULT 'DRAFT',
      published INTEGER DEFAULT 0,
      categoryId INTEGER,
      createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (categoryId) REFERENCES EventCategory(id)
    );
CREATE TABLE Speaker (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      firstName TEXT NOT NULL,
      lastName TEXT NOT NULL,
      organization TEXT,
      bio TEXT,
      photoUrl TEXT,
      createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
CREATE TABLE EventSpeaker (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      eventId INTEGER NOT NULL,
      speakerId INTEGER NOT NULL,
      role TEXT,
      displayOrder INTEGER DEFAULT 0,
      createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (eventId) REFERENCES Event(id) ON DELETE CASCADE,
      FOREIGN KEY (speakerId) REFERENCES Speaker(id) ON DELETE CASCADE
    );
CREATE TABLE Publication (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      abstract TEXT,
      content TEXT,
      status TEXT DEFAULT 'DRAFT',
      publishedDate DATETIME,
      coverImage TEXT,
      categoryId INTEGER,
      createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (categoryId) REFERENCES categories(id)
    );
CREATE TABLE tags_on_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      eventId INTEGER NOT NULL,
      tagId INTEGER NOT NULL,
      createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (eventId) REFERENCES Event(id) ON DELETE CASCADE,
      FOREIGN KEY (tagId) REFERENCES tags(id) ON DELETE CASCADE
    );
CREATE TABLE error_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      message TEXT NOT NULL,
      stack TEXT,
      path TEXT,
      method TEXT,
      userId INTEGER,
      severity TEXT DEFAULT 'ERROR',
      metadata TEXT,
      createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (userId) REFERENCES users(id)
    );
CREATE INDEX idx_events_status ON Event(status);
CREATE INDEX idx_events_category_id ON Event(categoryId);
CREATE INDEX idx_events_start_date ON Event(startDate);
CREATE INDEX idx_events_slug ON Event(slug);
CREATE INDEX idx_tags_name ON tags(name);
CREATE INDEX idx_tags_slug ON tags(slug);
CREATE INDEX idx_categories_slug ON categories(slug);
CREATE INDEX idx_event_speakers_event_id ON EventSpeaker(eventId);
CREATE INDEX idx_event_speakers_speaker_id ON EventSpeaker(speakerId);
CREATE INDEX idx_tags_on_events_event_id ON tags_on_events(eventId);
CREATE INDEX idx_tags_on_events_tag_id ON tags_on_events(tagId);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_profiles_user_id ON profiles(userId);
CREATE INDEX idx_profiles_email ON profiles(email);
CREATE INDEX idx_publications_slug ON Publication(slug);
CREATE INDEX idx_publications_status ON Publication(status);
CREATE INDEX idx_publications_category_id ON Publication(categoryId);
CREATE INDEX idx_error_logs_created_at ON error_logs(createdAt);
CREATE INDEX idx_error_logs_severity ON error_logs(severity);
CREATE TABLE event_categories (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        description TEXT,
        createdAt DATETIME NOT NULL,
        updatedAt DATETIME NOT NULL
      );
CREATE TABLE events (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        description TEXT NOT NULL,
        content TEXT,
        location TEXT NOT NULL,
        venue TEXT,
        startDate DATETIME NOT NULL,
        endDate DATETIME NOT NULL,
        posterImage TEXT,
        posterCredit TEXT,
        status TEXT NOT NULL,
        published INTEGER NOT NULL DEFAULT 0,
        categoryId TEXT,
        createdAt DATETIME NOT NULL,
        updatedAt DATETIME NOT NULL,
        FOREIGN KEY (categoryId) REFERENCES event_categories(id)
      );
CREATE TABLE speakers (
        id TEXT PRIMARY KEY,
        firstName TEXT NOT NULL,
        lastName TEXT NOT NULL,
        title TEXT,
        bio TEXT,
        organization TEXT,
        photoUrl TEXT,
        createdAt DATETIME NOT NULL,
        updatedAt DATETIME NOT NULL
      );
CREATE TABLE event_speakers (
        id TEXT PRIMARY KEY,
        eventId TEXT NOT NULL,
        speakerId TEXT NOT NULL,
        displayOrder INTEGER NOT NULL,
        role TEXT,
        createdAt DATETIME NOT NULL,
        updatedAt DATETIME NOT NULL,
        FOREIGN KEY (eventId) REFERENCES events(id),
        FOREIGN KEY (speakerId) REFERENCES speakers(id),
        UNIQUE(eventId, speakerId)
      );
CREATE TABLE publications (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        abstract TEXT NOT NULL,
        content TEXT,
        publicationDate DATETIME,
        coverImage TEXT,
        imageCredit TEXT,
        published INTEGER NOT NULL DEFAULT 0,
        categoryId TEXT,
        createdAt DATETIME NOT NULL,
        updatedAt DATETIME NOT NULL,
        FOREIGN KEY (categoryId) REFERENCES event_categories(id)
      );
CREATE TABLE categories_on_publications (
        id TEXT PRIMARY KEY,
        publicationId TEXT NOT NULL,
        categoryId TEXT NOT NULL,
        createdAt DATETIME NOT NULL,
        FOREIGN KEY (publicationId) REFERENCES publications(id),
        FOREIGN KEY (categoryId) REFERENCES event_categories(id),
        UNIQUE(publicationId, categoryId)
      );
CREATE TABLE tags_on_publications (
        id TEXT PRIMARY KEY,
        publicationId TEXT NOT NULL,
        tagId TEXT NOT NULL,
        createdAt DATETIME NOT NULL,
        FOREIGN KEY (publicationId) REFERENCES publications(id),
        FOREIGN KEY (tagId) REFERENCES tags(id),
        UNIQUE(publicationId, tagId)
      );
CREATE TABLE publication_files (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        url TEXT NOT NULL,
        size INTEGER NOT NULL,
        type TEXT NOT NULL,
        publicationId TEXT NOT NULL,
        createdAt DATETIME NOT NULL,
        updatedAt DATETIME NOT NULL,
        FOREIGN KEY (publicationId) REFERENCES publications(id)
      );
CREATE INDEX idx_events_published ON events(published);
CREATE INDEX idx_events_categoryId ON events(categoryId);
CREATE INDEX idx_events_startDate ON events(startDate);
CREATE INDEX idx_events_title ON events(title);
CREATE INDEX idx_events_createdAt ON events(createdAt);
CREATE INDEX idx_event_categories_slug ON event_categories(slug);
CREATE INDEX idx_event_categories_name ON event_categories(name);
CREATE INDEX idx_publications_published ON publications(published);
CREATE INDEX idx_publications_categoryId ON publications(categoryId);
CREATE INDEX idx_publications_title ON publications(title);
CREATE INDEX idx_publications_createdAt ON publications(createdAt);
CREATE INDEX idx_event_speakers_eventId ON event_speakers(eventId);
CREATE INDEX idx_event_speakers_speakerId ON event_speakers(speakerId);
CREATE INDEX idx_categories_publications_publicationId ON categories_on_publications(publicationId);
CREATE INDEX idx_tags_events_eventId ON tags_on_events(eventId);
CREATE INDEX idx_tags_publications_publicationId ON tags_on_publications(publicationId);
CREATE INDEX idx_publication_files_publicationId ON publication_files(publicationId);
CREATE INDEX idx_events_combined ON events(status, published, categoryId);
CREATE INDEX idx_publications_combined ON publications(published, categoryId);
CREATE TABLE sqlite_stat1(tbl,idx,stat);
CREATE TABLE sqlite_stat4(tbl,idx,neq,nlt,ndlt,sample);
CREATE INDEX idx_events_category ON events(categoryId);
CREATE TABLE presentation (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        abstract TEXT,
        speakerId TEXT NOT NULL,
        eventId TEXT,
        slides TEXT,
        videoUrl TEXT,
        duration INTEGER,
        startTime DATETIME,
        endTime DATETIME,
        createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (speakerId) REFERENCES speakers(id),
        FOREIGN KEY (eventId) REFERENCES events(id)
      );
CREATE INDEX idx_presentations_speakerId ON presentation(speakerId);
CREATE INDEX idx_presentations_eventId ON presentation(eventId);
CREATE INDEX idx_presentations_title ON presentation(title);
CREATE INDEX idx_presentations_startTime ON presentation(startTime);
CREATE TABLE authors (
          id TEXT PRIMARY KEY,
          firstName TEXT NOT NULL,
          lastName TEXT NOT NULL,
          email TEXT UNIQUE NOT NULL,
          phoneNumber TEXT,
          organization TEXT,
          bio TEXT,
          category TEXT NOT NULL,
          photoUrl TEXT,
          createdAt DATETIME NOT NULL,
          updatedAt DATETIME NOT NULL
        );
CREATE INDEX idx_authors_email ON authors(email);
CREATE INDEX idx_authors_category ON authors(category);
CREATE TABLE authors_on_publications (
          id TEXT PRIMARY KEY,
          publicationId TEXT NOT NULL,
          authorId TEXT NOT NULL,
          displayOrder INTEGER NOT NULL,
          role TEXT,
          createdAt DATETIME NOT NULL,
          updatedAt DATETIME NOT NULL,
          FOREIGN KEY (publicationId) REFERENCES publications(id),
          FOREIGN KEY (authorId) REFERENCES authors(id),
          UNIQUE(publicationId, authorId)
        );
CREATE INDEX idx_authors_publications_pub ON authors_on_publications(publicationId);
CREATE INDEX idx_authors_publications_author ON authors_on_publications(authorId);
CREATE TABLE tasks (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL,
  priority TEXT NOT NULL,
  dueDate DATETIME,
  completedDate DATETIME,
  -- Person who delegates/creates the task (A)
  delegatedBy TEXT NOT NULL,
  -- Person who performs the task (B)
  assignedTo TEXT,
  -- For tracking review status
  reviewStatus TEXT DEFAULT 'PENDING', -- PENDING, NEEDS_UPDATE, ACCEPTED
  reviewComment TEXT,
  reviewDate DATETIME,
  -- The original creator ID for compatibility
  createdBy TEXT,
  agentId TEXT,
  tags TEXT,
  -- Shared files for the task (JSON array of file paths/urls)
  sharedFiles TEXT,
  -- Soft delete flag (0 = active, 1 = deleted)
  deleted INTEGER DEFAULT 0,
  createdAt DATETIME NOT NULL,
  updatedAt DATETIME NOT NULL
, projectId TEXT, parentTaskId TEXT, estimatedHours REAL);
CREATE INDEX idx_tasks_delegated_by ON tasks(delegatedBy);
CREATE INDEX idx_tasks_assigned_to ON tasks(assignedTo);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_review_status ON tasks(reviewStatus);
CREATE INDEX idx_tasks_deleted ON tasks(deleted);
CREATE TABLE projects (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  startDate DATETIME,
  dueDate DATETIME,
  status TEXT NOT NULL DEFAULT 'ACTIVE', -- ACTIVE, COMPLETED, ARCHIVED
  ownerId TEXT NOT NULL,
  deleted INTEGER DEFAULT 0,
  createdAt DATETIME NOT NULL,
  updatedAt DATETIME NOT NULL
);
CREATE TABLE project_members (
  id TEXT PRIMARY KEY,
  projectId TEXT NOT NULL,
  userId TEXT NOT NULL,
  role TEXT NOT NULL, -- ADMIN, MANAGER, MEMBER
  createdAt DATETIME NOT NULL,
  updatedAt DATETIME NOT NULL,
  FOREIGN KEY (projectId) REFERENCES projects(id),
  FOREIGN KEY (userId) REFERENCES users(id),
  UNIQUE(projectId, userId)
);
CREATE TABLE milestones (
  id TEXT PRIMARY KEY,
  projectId TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  dueDate DATETIME,
  status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, COMPLETED
  createdAt DATETIME NOT NULL,
  updatedAt DATETIME NOT NULL,
  FOREIGN KEY (projectId) REFERENCES projects(id)
);
CREATE TABLE time_logs (
  id TEXT PRIMARY KEY,
  taskId TEXT NOT NULL,
  userId TEXT NOT NULL,
  startTime DATETIME NOT NULL,
  endTime DATETIME,
  duration INTEGER, -- in seconds
  notes TEXT,
  createdAt DATETIME NOT NULL,
  updatedAt DATETIME NOT NULL,
  FOREIGN KEY (taskId) REFERENCES tasks(id),
  FOREIGN KEY (userId) REFERENCES users(id)
);
CREATE TABLE comments (
  id TEXT PRIMARY KEY,
  content TEXT NOT NULL,
  entityType TEXT NOT NULL, -- PROJECT, TASK
  entityId TEXT NOT NULL,
  userId TEXT NOT NULL,
  parentCommentId TEXT,
  createdAt DATETIME NOT NULL,
  updatedAt DATETIME NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id)
);
CREATE TABLE attachments (
  id TEXT PRIMARY KEY,
  fileName TEXT NOT NULL,
  fileSize INTEGER NOT NULL,
  fileType TEXT NOT NULL,
  filePath TEXT NOT NULL,
  entityType TEXT NOT NULL, -- PROJECT, TASK, COMMENT
  entityId TEXT NOT NULL,
  userId TEXT NOT NULL,
  version INTEGER DEFAULT 1,
  createdAt DATETIME NOT NULL,
  updatedAt DATETIME NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id)
);
CREATE TABLE notifications (
  id TEXT PRIMARY KEY,
  userId TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL, -- TASK_ASSIGNED, DEADLINE_APPROACHING, COMMENT_ADDED, etc.
  entityType TEXT NOT NULL, -- PROJECT, TASK
  entityId TEXT NOT NULL,
  isRead INTEGER DEFAULT 0,
  createdAt DATETIME NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id)
);
CREATE INDEX idx_projects_owner ON projects(ownerId);
CREATE INDEX idx_projects_deleted ON projects(deleted);
CREATE INDEX idx_project_members_project ON project_members(projectId);
CREATE INDEX idx_project_members_user ON project_members(userId);
CREATE INDEX idx_milestones_project ON milestones(projectId);
CREATE INDEX idx_tasks_project ON tasks(projectId);
CREATE INDEX idx_tasks_parent ON tasks(parentTaskId);
CREATE INDEX idx_time_logs_task ON time_logs(taskId);
CREATE INDEX idx_time_logs_user ON time_logs(userId);
CREATE INDEX idx_comments_entity ON comments(entityType, entityId);
CREATE INDEX idx_attachments_entity ON attachments(entityType, entityId);
CREATE INDEX idx_notifications_user ON notifications(userId);
CREATE INDEX idx_tasks_assignedTo ON tasks(assignedTo);
CREATE INDEX idx_presentation_speaker ON presentation(speakerId);
CREATE INDEX idx_presentation_event ON presentation(eventId);
