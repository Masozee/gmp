const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

// Path to the database file
const dbPath = path.join(__dirname, '../src/db/app.db');
const outputDir = path.join(__dirname, 'tables');

// Create/open the database
const db = new sqlite3.Database(dbPath);

// Get all tables from the database
db.all("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'", (err, tables) => {
  if (err) {
    console.error('Error retrieving tables:', err);
    closeDb();
    return;
  }

  console.log(`Found ${tables.length} tables to export`);
  
  // Process each table
  let completedTables = 0;
  
  tables.forEach(table => {
    const tableName = table.name;
    exportTable(tableName, () => {
      completedTables++;
      if (completedTables === tables.length) {
        console.log('All tables exported successfully');
        closeDb();
      }
    });
  });
});

// Function to export a table to CSV
function exportTable(tableName, callback) {
  // Get all data from the table
  db.all(`SELECT * FROM "${tableName}"`, (err, rows) => {
    if (err) {
      console.error(`Error exporting table ${tableName}:`, err);
      callback();
      return;
    }
    
    if (rows.length === 0) {
      console.log(`Table ${tableName} is empty. Skipping.`);
      callback();
      return;
    }
    
    // Create CSV header
    const headers = Object.keys(rows[0]);
    let csvContent = headers.join(',') + '\n';
    
    // Add data rows
    rows.forEach(row => {
      const values = headers.map(header => {
        const value = row[header];
        // Handle null values, strings with commas, and quotes
        if (value === null || value === undefined) {
          return '';
        } else if (typeof value === 'string') {
          // Escape quotes and wrap in quotes if contains comma or newline
          const escaped = value.replace(/"/g, '""');
          if (escaped.includes(',') || escaped.includes('\n') || escaped.includes('"')) {
            return `"${escaped}"`;
          }
          return escaped;
        }
        return value;
      }).join(',');
      
      csvContent += values + '\n';
    });
    
    // Write to file
    const outputPath = path.join(outputDir, `${tableName}.csv`);
    fs.writeFile(outputPath, csvContent, err => {
      if (err) {
        console.error(`Error writing CSV for ${tableName}:`, err);
      } else {
        console.log(`Exported ${rows.length} rows from ${tableName} to ${outputPath}`);
      }
      callback();
    });
  });
}

// Function to close the database
function closeDb() {
  db.close(err => {
    if (err) {
      console.error('Error closing database:', err);
      process.exit(1);
    } else {
      console.log('Database connection closed');
      process.exit(0);
    }
  });
} 